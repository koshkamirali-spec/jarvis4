from pathlib import Path
import re

gradle = Path("android/app/build.gradle.kts")
if gradle.exists():
    text = gradle.read_text()
    if "isCoreLibraryDesugaringEnabled" not in text:
        text = re.sub(r"compileOptions \{", "compileOptions {\n        isCoreLibraryDesugaringEnabled = true", text, count=1)
    if "desugar_jdk_libs" not in text:
        text = re.sub(r"dependencies \{", 'dependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")', text, count=1)
    gradle.write_text(text)

plist = Path("ios/Runner/Info.plist")
if plist.exists():
    text = plist.read_text()
    entries = {
        "NSCameraUsageDescription": "برای گرفتن عکس جهت تحلیل یا استخراج متن، با اجازه شما.",
        "NSPhotoLibraryUsageDescription": "برای انتخاب تصویری که خودتان برای تحلیل یا OCR انتخاب می‌کنید.",
        "NSLocationWhenInUseUsageDescription": "برای نمایش آب‌وهوای محل فعلی، فقط هنگام استفاده از این قابلیت.",
        "NSMicrophoneUsageDescription": "برای تبدیل گفتار شما به متن هنگام استفاده از دستیار صوتی.",
    }
    for key, value in entries.items():
        if f"<key>{key}</key>" not in text:
            text = text.replace("</dict>", f"<key>{key}</key>\n<string>{value}</string>\n</dict>")
    plist.write_text(text)

podfile = Path("ios/Podfile")
if podfile.exists():
    text = podfile.read_text()
    if "platform :ios" in text:
        text = re.sub(r"platform :ios, ['\"][^'\"]+['\"]", "platform :ios, '15.5'", text, count=1)
    else:
        text = "platform :ios, '15.5'\n" + text
    podfile.write_text(text)

# Keep the user-started Android wake-word foreground service after `flutter create .`.
manifest = Path("android/app/src/main/AndroidManifest.xml")
if manifest.exists():
    text = manifest.read_text()
    permissions = [
        '    <uses-permission android:name="android.permission.INTERNET" />',
        '    <uses-permission android:name="android.permission.RECORD_AUDIO" />',
        '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />',
        '    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MICROPHONE" />',
        '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
        '    <uses-permission android:name="android.permission.CAMERA" />',
        '    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
        '    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
    ]
    for permission in permissions:
        name = re.search(r'android:name="([^"]+)"', permission).group(1)
        if f'android:name="{name}"' not in text:
            text = text.replace('</manifest>', permission + '\n</manifest>')
    service_name = 'com.example.jarvis.JarvisWakeWordService'
    if service_name not in text:
        service = '''        <service
            android:name="com.example.jarvis.JarvisWakeWordService"
            android:label="JARVIS Wake Word"
            android:exported="false"
            android:foregroundServiceType="microphone" />\n'''
        text = text.replace('    </application>', service + '    </application>')
    notification_service = '''        <service
            android:name="com.example.jarvis.JarvisNotificationListener"
            android:label="JARVIS Notification Access"
            android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE"
            android:exported="true">
            <intent-filter>
                <action android:name="android.service.notification.NotificationListenerService" />
            </intent-filter>
        </service>\n'''
    if 'com.example.jarvis.JarvisNotificationListener' not in text:
        text = text.replace('    </application>', notification_service + '    </application>')
    manifest.write_text(text)

# Keep the Android min SDK aligned with runtime permission APIs used by the native bridge.
gradle = Path('android/app/build.gradle.kts')
if gradle.exists():
    text = gradle.read_text()
    text = re.sub(r'minSdk = flutter\.minSdkVersion', 'minSdk = 23', text)
    gradle.write_text(text)
