import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis/core/services/local_command_service.dart';

void main() {
  group('LocalCommandService', () {
    final service = LocalCommandService();
    test('calculates with operator precedence', () {
      expect(service.answer('حساب کن ۱۲ + ۵ × ۳'), 'نتیجه: 27');
    });
    test('supports parentheses', () {
      expect(service.answer('calculate (8 + 2) / 5'), 'نتیجه: 2');
    });
    test('rejects division by zero safely', () {
      expect(service.answer('حساب کن 4 / 0'), contains('قابل محاسبه نیست'));
    });
    test('does not treat arbitrary text as a local command', () {
      expect(service.answer('برای من یک داستان بنویس'), isNull);
    });
  });
}
