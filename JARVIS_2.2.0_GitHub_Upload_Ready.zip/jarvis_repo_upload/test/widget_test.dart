import 'package:flutter_test/flutter_test.dart';
import 'package:jarvis/app.dart';

void main() {
  testWidgets('JARVIS app starts and shows its home screen', (tester) async {
    await tester.pumpWidget(const JarvisApp());
    await tester.pumpAndSettle();
    expect(find.textContaining('J.A.R.V.I.S'), findsWidgets);
  });
}
