import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'dart:async';

class JarvisDeviceBridge {
  static const MethodChannel _channel = MethodChannel('com.jarvis.ai/device');
  static const EventChannel _wakeEvents = EventChannel('com.jarvis.ai/wake_events');
  static final Stream<String> wakeEvents = _wakeEvents.receiveBroadcastStream().where((event) => event == 'wake_detected').cast<String>().asBroadcastStream();

  Future<bool> startWakeWordService() async {
    if (!supported) return false;
    return await _channel.invokeMethod<bool>('startWakeWordService') ?? false;
  }

  Future<void> stopWakeWordService() async {
    if (supported) await _channel.invokeMethod('stopWakeWordService');
  }

  Future<bool> isWakeWordServiceRunning() async {
    if (!supported) return false;
    return await _channel.invokeMethod<bool>('isWakeWordServiceRunning') ?? false;
  }
  static bool get supported => !kIsWeb && defaultTargetPlatform == TargetPlatform.android;

  Future<bool> hasNotificationAccess() async {
    if (!supported) return false;
    return await _channel.invokeMethod<bool>('hasNotificationAccess') ?? false;
  }

  Future<void> openNotificationAccessSettings() async {
    if (supported) await _channel.invokeMethod('openNotificationAccessSettings');
  }

  Future<List<Map<String, String>>> activeNotifications() async {
    if (!supported) return const [];
    final rows = await _channel.invokeListMethod<dynamic>('getActiveNotifications') ?? const [];
    return rows.whereType<Map>().map((row) => row.map((k, v) => MapEntry(k.toString(), v.toString()))).toList();
  }

  Future<bool> openApp(String packageName) async {
    if (!supported) return false;
    return await _channel.invokeMethod<bool>('openApp', {'packageName': packageName}) ?? false;
  }

  Future<void> openOwnAppSettings() async {
    if (supported) await _channel.invokeMethod('openAppSettings');
  }

  Future<bool> openSystemSettings(String section) async {
    if (!supported) return false;
    return await _channel.invokeMethod<bool>('openSystemSettings', {'section': section}) ?? false;
  }

  Future<bool> openDialer(String? number) async {
    if (!supported) return false;
    return await _channel.invokeMethod<bool>('openDialer', {'number': number ?? ''}) ?? false;
  }

  Future<bool> composeSms(String? number, String? body) async {
    if (!supported) return false;
    return await _channel.invokeMethod<bool>('composeSms', {'number': number ?? '', 'body': body ?? ''}) ?? false;
  }
}
