import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

/// The mobile app talks only to the user's backend. Never embed a Gemini key here.
class AiService {
  AiService({required this.endpoint});
  final String endpoint;
  Future<String> ask(String prompt, {List<Map<String, String>> history = const []}) async {
    final base = Uri.tryParse(endpoint);
    if (base == null || !base.hasScheme || !{'http','https'}.contains(base.scheme)) {
      throw StateError('آدرس بک‌اند تنظیم نشده است. JARVIS_API_URL باید به نشانی /chat اشاره کند.');
    }
    final response = await http.post(base,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'message': prompt, 'history': history}),
    ).timeout(const Duration(seconds: 45));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      String detail = 'خطای سرور ${response.statusCode}';
      try { detail = (jsonDecode(response.body)['error'] ?? detail).toString(); } catch (_) {}
      throw Exception(detail);
    }
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return (data['reply'] ?? 'پاسخی دریافت نشد.').toString();
  }

  Future<String> analyzeImage(File file, {String prompt = 'این تصویر را با دقت توصیف و تحلیل کن.'}) async {
    final uri = _endpoint('/analyze-image');
    final bytes = await file.readAsBytes();
    final response = await http.post(uri, headers: {'Content-Type': 'application/json'}, body: jsonEncode({
      'prompt': prompt, 'mimeType': _mimeType(file.path), 'imageBase64': base64Encode(bytes),
    })).timeout(const Duration(seconds: 60));
    if (response.statusCode < 200 || response.statusCode >= 300) throw Exception(_error(response));
    return (jsonDecode(response.body)['reply'] ?? 'تحلیلی دریافت نشد.').toString();
  }

  Future<String> searchWeb(String query) async {
    final response = await http.post(_endpoint('/search'), headers: {'Content-Type':'application/json'}, body: jsonEncode({'query':query})).timeout(const Duration(seconds:30));
    if (response.statusCode < 200 || response.statusCode >= 300) throw Exception(_error(response));
    final data = jsonDecode(response.body) as Map<String,dynamic>;
    final results = (data['results'] as List? ?? const []);
    if (results.isEmpty) return 'نتیجه‌ای پیدا نشد.';
    return results.map((r) => '• ${r['title']}\n${r['snippet']}\n${r['link']}').join('\n\n');
  }

  Uri _endpoint(String path) {
    final base = Uri.tryParse(endpoint);
    if (base == null || !base.hasScheme || !{'http','https'}.contains(base.scheme)) throw StateError('آدرس بک‌اند تنظیم نشده است.');
    return base.replace(path: path, query: null, fragment: null);
  }
  String _error(http.Response response) {
    try { return (jsonDecode(response.body)['error'] ?? 'خطای سرور ${response.statusCode}').toString(); } catch (_) { return 'خطای سرور ${response.statusCode}'; }
  }
  String _mimeType(String path) {
    final p = path.toLowerCase();
    if (p.endsWith('.png')) return 'image/png';
    if (p.endsWith('.webp')) return 'image/webp';
    return 'image/jpeg';
  }
}
