import 'dart:convert';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

class WeatherSnapshot { WeatherSnapshot(this.temperature,this.wind,this.code,this.latitude,this.longitude); final double temperature,wind,latitude,longitude; final int code; }
class WeatherService {
 Future<WeatherSnapshot> current() async {
  if(!await Geolocator.isLocationServiceEnabled()) throw Exception('مکان‌یابی گوشی خاموش است.');
  var permission=await Geolocator.checkPermission();
  if(permission==LocationPermission.denied) permission=await Geolocator.requestPermission();
  if(permission==LocationPermission.denied || permission==LocationPermission.deniedForever) throw Exception('مجوز مکان داده نشد.');
  final pos=await Geolocator.getCurrentPosition(locationSettings:const LocationSettings(accuracy:LocationAccuracy.low,timeLimit:Duration(seconds:15)));
  final uri=Uri.https('api.open-meteo.com','/v1/forecast',{'latitude':'${pos.latitude}','longitude':'${pos.longitude}','current':'temperature_2m,wind_speed_10m,weather_code','timezone':'auto'});
  final response=await http.get(uri).timeout(const Duration(seconds:20));
  if(response.statusCode!=200) throw Exception('سرویس آب‌وهوا پاسخ نداد.');
  final current=(jsonDecode(response.body)['current'] as Map<String,dynamic>);
  return WeatherSnapshot((current['temperature_2m'] as num).toDouble(),(current['wind_speed_10m'] as num).toDouble(),(current['weather_code'] as num).toInt(),pos.latitude,pos.longitude);
 }
 String description(int c){if(c==0)return'صاف';if([1,2,3].contains(c))return'نیمه‌ابری تا ابری';if([45,48].contains(c))return'مه‌آلود';if([51,53,55,61,63,65,80,81,82].contains(c))return'بارانی';if([71,73,75,77,85,86].contains(c))return'برفی';if([95,96,99].contains(c))return'رعدوبرق';return'شرایط متغیر';}
}
