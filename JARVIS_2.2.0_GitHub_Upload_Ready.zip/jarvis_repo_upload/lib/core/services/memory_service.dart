import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Stores user-created memories in Android Keystore / iOS Keychain-backed storage.
/// This is device-local secure storage, not cloud synchronization.
class MemoryService {
  static const _key = 'jarvis_user_memories_secure_v2';
  static const _legacyKey = 'jarvis_user_memories';
  static const FlutterSecureStorage _storage = FlutterSecureStorage();

  Future<List<String>> all() async {
    final raw = await _storage.read(key: _key);
    if (raw != null) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is List) return decoded.whereType<String>().toList();
      } catch (_) {}
    }
    final prefs = await SharedPreferences.getInstance();
    final legacy = prefs.getStringList(_legacyKey) ?? <String>[];
    if (legacy.isNotEmpty) {
      await _write(legacy);
      await prefs.remove(_legacyKey);
      return legacy;
    }
    return <String>[];
  }

  Future<void> migrateLegacy(List<String> legacyItems) async {
    if (await _storage.read(key: _key) != null || legacyItems.isEmpty) return;
    await _write(legacyItems);
  }

  Future<void> add(String value) async {
    final clean = value.trim();
    if (clean.isEmpty) return;
    final items = await all();
    if (!items.contains(clean)) {
      items.add(clean);
      await _write(items);
    }
  }

  Future<void> remove(String value) async {
    final items = await all();
    items.remove(value);
    await _write(items);
  }

  Future<void> clear() => _storage.delete(key: _key);

  Future<void> _write(List<String> items) =>
      _storage.write(key: _key, value: jsonEncode(items));
}
