import 'package:shared_preferences/shared_preferences.dart';
class SettingsService {
  Future<String> language() async => (await SharedPreferences.getInstance()).getString('language') ?? 'auto';
  Future<void> setLanguage(String value) async => (await SharedPreferences.getInstance()).setString('language', value);
  Future<bool> voiceEnabled() async => (await SharedPreferences.getInstance()).getBool('voice_enabled') ?? true;
  Future<void> setVoiceEnabled(bool value) async => (await SharedPreferences.getInstance()).setBool('voice_enabled', value);
  Future<bool> shareMemoryWithAssistant() async => (await SharedPreferences.getInstance()).getBool('share_memory_with_assistant') ?? false;
  Future<void> setShareMemoryWithAssistant(bool value) async => (await SharedPreferences.getInstance()).setBool('share_memory_with_assistant', value);
  Future<String> displayName() async => (await SharedPreferences.getInstance()).getString('display_name') ?? 'کاربر';
  Future<void> setDisplayName(String value) async => (await SharedPreferences.getInstance()).setString('display_name', value.trim());
}
