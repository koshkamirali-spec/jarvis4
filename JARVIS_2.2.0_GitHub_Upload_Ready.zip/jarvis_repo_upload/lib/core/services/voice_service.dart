import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:shared_preferences/shared_preferences.dart';

class JarvisVoice {
  const JarvisVoice({required this.id, required this.name, required this.locale, required this.raw, required this.isMale});
  final String id;
  final String name;
  final String locale;
  final Map<String, String> raw;
  final bool isMale;
  String get label => '$name ($locale)${isMale ? ' • مردانه' : ''}';
}

class VoiceService {
  final SpeechToText _speech = SpeechToText();
  final FlutterTts _tts = FlutterTts();
  static const _voiceKey = 'jarvis_tts_voice_id';

  Future<bool> initialize() => _speech.initialize();

  Future<List<JarvisVoice>> availableVoices({String languagePrefix = 'fa'}) async {
    final rawVoices = await _tts.getVoices;
    final voices = <JarvisVoice>[];
    for (final item in (rawVoices as List? ?? const [])) {
      if (item is! Map) continue;
      final map = item.map((k, v) => MapEntry(k.toString(), v.toString()));
      final locale = map['locale'] ?? '';
      if (locale.isNotEmpty && !locale.toLowerCase().startsWith(languagePrefix.toLowerCase())) continue;
      final name = map['name'] ?? map['identifier'] ?? 'Voice';
      final gender = (map['gender'] ?? '').toLowerCase();
      final isMale = gender == 'male' || RegExp(r'\b(male|man|masculine|david|george|mark|alex|daniel|google.*male)\b', caseSensitive: false).hasMatch(name);
      final id = map['identifier'] ?? '${map['name']}|$locale';
      voices.add(JarvisVoice(id: id, name: name, locale: locale, raw: map, isMale: isMale));
    }
    voices.sort((a, b) => (b.isMale ? 1 : 0).compareTo(a.isMale ? 1 : 0));
    return voices;
  }

  Future<String?> savedVoiceId() async => (await SharedPreferences.getInstance()).getString(_voiceKey);
  Future<void> saveVoice(JarvisVoice voice) async {
    await _tts.setVoice(voice.raw);
    await (await SharedPreferences.getInstance()).setString(_voiceKey, voice.id);
  }
  Future<void> applySavedVoice({String language = 'fa-IR'}) async {
    await _tts.setLanguage(language);
    final id = await savedVoiceId();
    final voices = await availableVoices(languagePrefix: language.substring(0, 2));
    JarvisVoice? selected;
    for (final voice in voices) { if (voice.id == id) selected = voice; }
    if (selected == null) {
      for (final voice in voices) { if (voice.isMale) { selected = voice; break; } }
    }
    if (selected != null) {
      await _tts.setVoice(selected.raw);
      if (id == null) await saveVoice(selected);
    }
  }
  Future<void> listen(void Function(String, bool) onText, {String locale = 'fa_IR'}) async {
    await _speech.listen(localeId: locale, listenFor: const Duration(seconds: 45), pauseFor: const Duration(seconds: 3), onResult: (r) => onText(r.recognizedWords, r.finalResult));
  }
  Future<void> stopListening() => _speech.stop();
  Future<void> speak(String text, {String language = 'fa-IR'}) async {
    await applySavedVoice(language: language);
    await _tts.speak(text);
  }
  Future<void> stopSpeaking() => _tts.stop();
}
