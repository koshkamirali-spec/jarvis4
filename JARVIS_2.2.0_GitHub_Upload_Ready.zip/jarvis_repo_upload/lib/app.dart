import 'package:flutter/material.dart';
import 'core/theme/jarvis_theme.dart';
import 'features/home/home_screen.dart';

class JarvisApp extends StatelessWidget {
  const JarvisApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'J.A.R.V.I.S', debugShowCheckedModeBanner: false,
    theme: JarvisTheme.dark, home: const HomeScreen(),
  );
}
