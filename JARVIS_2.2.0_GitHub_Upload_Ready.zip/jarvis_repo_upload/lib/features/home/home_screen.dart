import 'package:flutter/material.dart';
import 'dart:async';
import '../../core/services/device_bridge.dart';
import '../../core/theme/jarvis_theme.dart';
import '../chat/chat_screen.dart';
import '../modules/modules_screen.dart';
import '../settings/settings_screen.dart';
import '../tools/daily_tools_screen.dart';
import '../memory/memory_screen.dart';

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState() => _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  StreamSubscription<String>? wakeSubscription;
  @override void initState(){super.initState();wakeSubscription=JarvisDeviceBridge.wakeEvents.listen((_) { if(mounted)setState(()=>tab=1); });}
  @override void dispose(){wakeSubscription?.cancel();super.dispose();}
  final pages = const [Dashboard(), ChatScreen(), DailyToolsScreen(), MemoryScreen(), SettingsScreen()];
  @override Widget build(BuildContext context) => Scaffold(
    body: IndexedStack(index: tab, children: pages),
    bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v),
      destinations: const [NavigationDestination(icon: Icon(Icons.grid_view), label: 'خانه'), NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'گفت‌وگو'), NavigationDestination(icon: Icon(Icons.checklist), label: 'ابزارها'), NavigationDestination(icon: Icon(Icons.psychology_alt_outlined), label: 'حافظه'), NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'تنظیمات')]),
  );
}
class Dashboard extends StatelessWidget {
  const Dashboard({super.key});
  @override Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
    Row(children: [const Expanded(child: Text('J.A.R.V.I.S', style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold, letterSpacing: 2))), Icon(Icons.circle, color: JarvisTheme.cyan, size: 10), const SizedBox(width: 6), const Text('ONLINE', style: TextStyle(color: JarvisTheme.cyan, fontSize: 11))]),
    const SizedBox(height: 28),
    Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFF171D32), Color(0xFF251A3D)]), border: Border.all(color: JarvisTheme.cyan.withValues(alpha: .3))), child: const Column(children: [Icon(Icons.hub_outlined, size: 82, color: JarvisTheme.cyan), SizedBox(height: 12), Text('سیستم آماده است', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w600)), SizedBox(height: 6), Text('دستیار یکپارچه شخصی شما', style: TextStyle(color: Colors.white60))])),
    const SizedBox(height: 24), const Text('دسترسی سریع', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 10),
    _tile(context, 'گفت‌وگو با هوش مصنوعی', Icons.forum_outlined, 1), _tile(context, 'یادداشت‌ها و کارها', Icons.task_alt, 2), _tile(context, 'حافظه شخصی', Icons.memory, 3), _tile(context, 'ماژول‌ها و قابلیت‌ها', Icons.widgets_outlined, -1), _tile(context, 'تنظیمات و مجوزها', Icons.tune, 4),
    const SizedBox(height: 12), const Text('نکته: قابلیت‌های وابسته به سیستم‌عامل فقط پس از دریافت مجوز و روی دستگاه سازگار فعال می‌شوند.', style: TextStyle(color: Colors.white54, fontSize: 12)),
  ]));
  Widget _tile(BuildContext c, String title, IconData icon, int index) => Card(child: ListTile(leading: Icon(icon, color: JarvisTheme.cyan), title: Text(title), trailing: const Icon(Icons.chevron_right), onTap: () { if (index == -1) { Navigator.push(c, MaterialPageRoute(builder: (_) => const ModulesScreen())); } else { final state = c.findAncestorStateOfType<_HomeScreenState>(); state?.setState(() => state.tab = index); } })));
}
