import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import '../../core/services/ai_service.dart';
import '../../core/services/voice_service.dart';
import '../../core/services/memory_service.dart';
import '../../core/services/settings_service.dart';
import '../../core/services/local_command_service.dart';
import '../../core/services/device_bridge.dart';

class ChatScreen extends StatefulWidget { const ChatScreen({super.key}); @override State<ChatScreen> createState()=>_ChatScreenState(); }
class _ChatScreenState extends State<ChatScreen>{ final input=TextEditingController(); final voice=VoiceService(); final memory=MemoryService(); final preferences=SettingsService(); final scroll=ScrollController(); final picker=ImagePicker(); final localCommands=LocalCommandService(); final device=JarvisDeviceBridge(); final messages=<({bool user,String text})>[]; bool busy=false; bool listening=false; StreamSubscription<String>? wakeSubscription; final ai=AiService(endpoint:const String.fromEnvironment('JARVIS_API_URL'));
 @override void initState(){super.initState();wakeSubscription=JarvisDeviceBridge.wakeEvents.listen((_) async { if(!mounted)return; if(!await preferences.voiceEnabled()) { if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('عبارت بیدارباش شنیده شد؛ ابزار صوتی داخل برنامه غیرفعال است.'))); return; } final ok=await voice.initialize(); if(!ok)return; if(mounted)setState(()=>listening=true); await _listenConversation(); }); }
 Future<void> send({String? voiceText})async{final text=(voiceText ?? input.text).trim();if(text.isEmpty||busy)return;
 final localAnswer=localCommands.answer(text);
 if(localAnswer!=null){setState((){messages.add((user:true,text:text));messages.add((user:false,text:localAnswer));input.clear();});return;}
 final appMatch=RegExp(r'^(?:باز کن|اجرا کن|open)\s+(.+)$',caseSensitive:false).firstMatch(text);
 if(appMatch!=null){final target=appMatch.group(1)!.trim().toLowerCase();final packages=<String,String>{'واتساپ':'com.whatsapp','whatsapp':'com.whatsapp','اینستاگرام':'com.instagram.android','instagram':'com.instagram.android','تلگرام':'org.telegram.messenger','telegram':'org.telegram.messenger','یوتیوب':'com.google.android.youtube','youtube':'com.google.android.youtube','تنظیمات':'android.settings','settings':'android.settings'};
  if(packages.containsKey(target)){setState(()=>messages.add((user:true,text:text)));try{if(packages[target]=='android.settings'){await device.openSystemSettings('general');}else{await device.openApp(packages[target]!);}if(mounted)setState(()=>messages.add((user:false,text:'درخواست بازکردن $target به سیستم ارسال شد.')));}catch(e){if(mounted)setState(()=>messages.add((user:false,text:'بازکردن برنامه انجام نشد: $e')));}return;}}
 final settingsMatch=RegExp(r'^(?:تنظیمات|settings)\s+(wifi|وای.?فای|بلوتوث|bluetooth|صدا|sound|صفحه.?نمایش|display|مکان|location)$',caseSensitive:false).firstMatch(text);
 if(settingsMatch!=null){final t=settingsMatch.group(1)!.toLowerCase();final section=t.contains('wifi')||t.contains('وای')?'wifi':(t.contains('بلوتوث')||t.contains('bluetooth')?'bluetooth':(t.contains('صدا')||t.contains('sound')?'sound':(t.contains('نمایش')||t.contains('display')?'display':'location')));setState(()=>messages.add((user:true,text:text)));try{await device.openSystemSettings(section);if(mounted)setState(()=>messages.add((user:false,text:'صفحه تنظیمات مربوط باز شد.')));}catch(e){if(mounted)setState(()=>messages.add((user:false,text:'بازکردن تنظیمات ممکن نشد: $e')));}return;}
 final dialMatch=RegExp(r'^(?:شماره.?گیری|تماس با|dial)\s*([+0-9۰-۹ ]*)$',caseSensitive:false).firstMatch(text);
 if(dialMatch!=null){final number=dialMatch.group(1)!.trim().replaceAll(' ','');setState(()=>messages.add((user:true,text:text)));try{await device.openDialer(number);if(mounted)setState(()=>messages.add((user:false,text:'شماره‌گیر باز شد؛ تماس فقط با تأیید خودت انجام می‌شود.')));}catch(e){if(mounted)setState(()=>messages.add((user:false,text:'بازکردن شماره‌گیر ممکن نشد: $e')));}return;}
 final smsMatch=RegExp(r'^پیامک به\s*([+0-9۰-۹ ]+)\s*[:،]\s*(.+)$',caseSensitive:false).firstMatch(text);
 if(smsMatch!=null){final number=smsMatch.group(1)!.trim().replaceAll(' ','');final body=smsMatch.group(2)!.trim();setState(()=>messages.add((user:true,text:text)));try{await device.composeSms(number,body);if(mounted)setState(()=>messages.add((user:false,text:'پیش‌نویس پیامک باز شد. پیام ارسال نشده؛ قبل از ارسال آن را بررسی کن.')));}catch(e){if(mounted)setState(()=>messages.add((user:false,text:'بازکردن پیامک ممکن نشد: $e')));}return;}
 setState((){messages.add((user:true,text:text));input.clear();busy=true;});try{final history=messages.length>1?messages.sublist(0,messages.length-1).take(12).map((m)=>{'role':m.user?'user':'model','content':m.text}).toList():<Map<String,String>>[];final shareMemory=await preferences.shareMemoryWithAssistant();final savedMemories=shareMemory?await memory.all():<String>[];final enrichedPrompt=savedMemories.isEmpty?text:'یادداشت‌های حافظه‌ای که کاربر خودش ذخیره کرده (فقط در صورت مرتبط بودن استفاده کن):\n${savedMemories.take(20).join('\n')}\n\nدرخواست فعلی کاربر: $text';final reply=await ai.ask(enrichedPrompt,history:history);if(!mounted)return;setState(()=>messages.add((user:false,text:reply))); if(listening && await preferences.voiceEnabled()) { await voice.speak(reply); }}catch(e){if(mounted)setState(()=>messages.add((user:false,text:'ارتباط برقرار نشد: $e\n\nبرای فعال‌شدن چت آنلاین، بک‌اند را اجرا و JARVIS_API_URL را تنظیم کن.')));}finally{if(mounted){setState(()=>busy=false); if(listening) { Future.delayed(const Duration(milliseconds:500), _listenConversation); }}}}
 Future<void> analyzePhoto() async { if (busy) return; final source = await showModalBottomSheet<ImageSource>(context:context,builder:(c)=>SafeArea(child:Wrap(children:[ListTile(leading:const Icon(Icons.photo_library),title:const Text('انتخاب از گالری'),onTap:()=>Navigator.pop(c,ImageSource.gallery)),ListTile(leading:const Icon(Icons.camera_alt),title:const Text('گرفتن عکس با دوربین'),onTap:()=>Navigator.pop(c,ImageSource.camera))]))); if(source==null)return; final picked=await picker.pickImage(source:source,imageQuality:82,maxWidth:1800); if(picked==null)return; setState(()=>busy=true); try { final result=await ai.analyzeImage(File(picked.path)); if(mounted)setState(()=>messages.add((user:false,text:'تحلیل تصویر:\n$result'))); } catch(e) { if(mounted)setState(()=>messages.add((user:false,text:'تحلیل تصویر انجام نشد: $e'))); } finally { if(mounted)setState(()=>busy=false); } }
 Future<void> searchWeb() async { final q=input.text.trim(); if(q.isEmpty||busy)return; input.clear(); setState(()=>busy=true); try { final result=await ai.searchWeb(q); if(mounted)setState(()=>messages.add((user:false,text:'نتایج جست‌وجو برای «$q»:\n$result'))); } catch(e) { if(mounted)setState(()=>messages.add((user:false,text:'جست‌وجوی وب در دسترس نیست: $e'))); } finally { if(mounted)setState(()=>busy=false); } }
 Future<void> toggleVoice() async {
  if (listening) { setState(() => listening = false); await voice.stopListening(); if (await device.isWakeWordServiceRunning()) { await device.startWakeWordService(); } return; }
  if (!await preferences.voiceEnabled()) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('ابتدا ابزارهای صوتی را در تنظیمات فعال کن.'))); return;
  }
  final ok = await voice.initialize();
  if (!ok) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تشخیص گفتار در این دستگاه در دسترس نیست.'))); return; }
  setState(() => listening = true);
  await _listenConversation();
}

Future<void> _listenConversation() async {
  if (!mounted || !listening || busy) return;
  try {
    await voice.listen((spoken, isFinal) {
      if (!mounted || !listening) return;
      setState(() => input.text = spoken);
      if (isFinal && spoken.trim().isNotEmpty) {
        final cleaned = spoken.replaceAll(RegExp(r'\bhey\s*jarvis\b|هی\s*جارویس', caseSensitive: false), '').trim();
        if (cleaned.isNotEmpty && !busy) { voice.stopListening(); send(voiceText: cleaned); }
      }
    });
  } catch (_) {
    if (mounted) setState(() => listening = false);
  }
}
 @override void dispose(){wakeSubscription?.cancel();input.dispose();scroll.dispose();voice.stopListening();voice.stopSpeaking();super.dispose();}
 @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('گفت‌وگو با جارویس'),actions:[IconButton(tooltip:'پاک‌کردن گفتگو',onPressed:busy?null:()=>setState(messages.clear),icon:const Icon(Icons.delete_outline))]),body:Column(children:[Expanded(child:messages.isEmpty?const Center(child:Padding(padding:EdgeInsets.all(30),child:Text('سلام! من جارویس هستم.\nپیامت را بنویس یا با میکروفون صحبت کن.',textAlign:TextAlign.center,style:TextStyle(fontSize:18,height:1.8)))):ListView.builder(controller:scroll,padding:const EdgeInsets.all(12),itemCount:messages.length,itemBuilder:(c,i){final m=messages[i];return Align(alignment:m.user?Alignment.centerRight:Alignment.centerLeft,child:ConstrainedBox(constraints:BoxConstraints(maxWidth:MediaQuery.sizeOf(c).width*.86),child:Card(color:m.user?const Color(0xFF182C3A):null,child:Padding(padding:const EdgeInsets.all(10),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(m.text),if(!m.user)Align(alignment:Alignment.centerLeft,child:IconButton(tooltip:'پخش پاسخ با صدای جارویس',visualDensity:VisualDensity.compact,onPressed:()async{if(await preferences.voiceEnabled()) { await voice.speak(m.text); } else if(mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('ابزارهای صوتی در تنظیمات غیرفعال هستند.'))); }},icon:const Icon(Icons.volume_up_outlined))) ]))))); })),if(busy)const LinearProgressIndicator(),SafeArea(child:Padding(padding:const EdgeInsets.all(10),child:Row(children:[Expanded(child:TextField(controller:input,minLines:1,maxLines:4,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'پیامت را بنویس...'))),IconButton(tooltip:'تحلیل تصویر',onPressed:busy?null:analyzePhoto,icon:const Icon(Icons.image_search)),IconButton(tooltip:'جست‌وجوی وب؛ عبارت را در کادر بنویس',onPressed:busy?null:searchWeb,icon:const Icon(Icons.travel_explore)),IconButton(tooltip:listening?'پایان مکالمه صوتی':'شروع مکالمه صوتی پیوسته تا زمان بازبودن صفحه',onPressed:toggleVoice,color:listening?Colors.red:null,icon:Icon(listening?Icons.hearing:Icons.mic_none)),IconButton(onPressed:busy?null:send,icon:const Icon(Icons.send))])))]));
}
