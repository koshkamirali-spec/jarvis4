import 'package:flutter/material.dart';
import 'ocr_screen.dart';
import 'weather_screen.dart';
import 'reminders_screen.dart';
import 'learning_screen.dart';
import 'file_intelligence_screen.dart';
import 'driving_mode_screen.dart';
import 'communication_screen.dart';
import 'home_assistant_screen.dart';
import 'device_access_screen.dart';

class ModulesScreen extends StatelessWidget {
  const ModulesScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('ماژول‌های J.A.R.V.I.S')),
    body: ListView(padding: const EdgeInsets.all(12), children: [
      const Padding(padding: EdgeInsets.all(8), child: Text('قابلیت‌های قابل استفاده', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))),
      _tile(context, 'یادآورها و اعلان زمان‌بندی‌شده', Icons.notifications_active_outlined, 'ثبت یادآور محلی روی دستگاه', const RemindersScreen()),
      _tile(context, 'OCR و استخراج متن', Icons.document_scanner_outlined, 'خواندن متن تصویر با پردازش محلی', const OcrScreen()),
      _tile(context, 'آب‌وهوا و موقعیت', Icons.cloud_outlined, 'گرفتن آب‌وهوای فعلی با اجازه مکان', const WeatherScreen()),
      _tile(context, 'دستیار آموزشی', Icons.school_outlined, 'ذخیره موضوع‌ها، هدف‌ها و نکته‌های مطالعه', const LearningScreen()),
      _tile(context, 'هوشمندی فایل‌ها', Icons.folder_open_outlined, 'خواندن فایل‌های متنی روی خود دستگاه', const FileIntelligenceScreen()),
      _tile(context, 'حالت رانندگی', Icons.directions_car_outlined, 'تعامل صوتی ساده؛ فقط هنگام توقف خودرو استفاده شود', const DrivingModeScreen()),
      _tile(context, 'تماس و پیامک', Icons.phone_in_talk_outlined, 'بازکردن شماره‌گیر و پیامک با تأیید خودت', const CommunicationScreen()),
      _tile(context, 'خانه هوشمند', Icons.home_outlined, 'اتصال واقعی به Home Assistant با توکن شخصی', const HomeAssistantScreen()),
      _tile(context, 'دسترسی‌های دستگاه', Icons.phonelink_setup, 'نمایش اعلان‌های فعال با مجوز اختیاری و بازکردن برنامه با شناسه بسته', const DeviceAccessScreen()),
      const SizedBox(height: 14),
      const Padding(padding: EdgeInsets.all(8), child: Text('محدودیت‌های سیستم‌عامل', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))),
      const _InfoTile('Hey JARVIS آزمایشی (Android)', 'در تنظیمات فعالش کن. سرویس میکروفون با اعلان دائمی عبارت «هی جارویس» را از طریق SpeechRecognizer دستگاه تشخیص می‌دهد؛ پس از شنیدن، اعلان را لمس کن تا گفت‌وگو باز شود. وابسته به موتور گفتار/اینترنت و نیازمند تست دستگاهی است؛ موتور آفلاین اختصاصی نیست.', Icons.hearing),
      const _InfoTile('iOS و اعلان‌ها', 'خواندن اعلان‌های سایر برنامه‌ها از طریق Notification Listener فقط در Android و پس از مجوز دستی در صفحه دسترسی‌های دستگاه در دسترس است؛ iOS این API عمومی را ارائه نمی‌کند.', Icons.notifications_none),
      const _InfoTile('کنترل کامل گوشی و اجرای برنامه‌ها', 'Android و iOS اجازه کنترل آزاد تنظیمات، بستن اجباری برنامه‌ها یا دورزدن مجوزها را به اپ معمولی نمی‌دهند. این نسخه فقط از مسیرهای رسمی و تأییدشده استفاده می‌کند.', Icons.apps),
      const _InfoTile('نسخه iOS', 'کد Flutter مشترک است؛ ساخت و امضای IPA به macOS/Xcode، حساب و تنظیمات امضای Apple و تست روی دستگاه واقعی نیاز دارد.', Icons.phone_iphone),
      const _InfoTile('حافظه ابری و پشتیبان‌گیری', 'حافظه فعلی محلی است. برای همگام‌سازی ابری باید سرویس حساب کاربری، رمزنگاری سمت کاربر و سیاست حذف/بازیابی جداگانه راه‌اندازی شود.', Icons.cloud_sync_outlined),
      const _InfoTile('ایمنی اضطراری', 'هیچ تماس یا ارسال موقعیت اضطراری خودکار انجام نمی‌شود. برای ایمنی، شماره‌گیری و ارسال پیام باید با اقدام آشکار کاربر انجام شود.', Icons.shield_outlined),
    ]),
  );
  Widget _tile(BuildContext c, String title, IconData icon, String subtitle, Widget page) => Card(child: ListTile(leading: Icon(icon, color: const Color(0xFF35DDF5)), title: Text(title), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => page))));
}

class _InfoTile extends StatelessWidget {
  const _InfoTile(this.title, this.body, this.icon);
  final String title, body; final IconData icon;
  @override Widget build(BuildContext context) => Card(child: ListTile(leading: Icon(icon, color: Colors.white54), title: Text(title), subtitle: Text(body)));
}
