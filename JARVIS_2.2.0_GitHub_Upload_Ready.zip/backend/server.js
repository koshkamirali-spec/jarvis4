import express from 'express';
import { GoogleGenAI } from '@google/genai';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';

const app = express();
app.use(helmet());
app.use(express.json({limit: '12mb'}));
app.use(rateLimit({windowMs: 60_000, limit: 30, standardHeaders: 'draft-7', legacyHeaders: false}));
app.get('/health', (_req,res) => res.json({ok:true, service:'jarvis-backend'}));
app.post('/chat', async (req, res) => {
  try {
    if (!process.env.GEMINI_API_KEY) return res.status(503).json({error:'Backend Gemini key is not configured.'});
    const message = String(req.body?.message ?? '').slice(0, 12000).trim();
    if (!message) return res.status(400).json({error:'message is required'});
    const history = Array.isArray(req.body?.history) ? req.body.history.slice(-12) : [];
    const transcript = history.map(x => `${x.role === 'model' ? 'Assistant' : 'User'}: ${String(x.content ?? '').slice(0,4000)}`).join('\n');
    const ai = new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});
    const result = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
      contents: `You are J.A.R.V.I.S., a helpful bilingual Persian/English personal assistant. Reply in the user's language. Be honest about actions: never claim to control the device or perform an action unless a connected tool actually did it.\n${transcript}\nUser: ${message}`
    });
    res.json({reply:result.text || 'پاسخی دریافت نشد.'});
  } catch (err) {
    console.error('chat request failed', err);
    res.status(500).json({error:'AI request failed. Check backend logs.'});
  }
});
app.post('/analyze-image', async (req, res) => {
  try {
    if (!process.env.GEMINI_API_KEY) return res.status(503).json({error:'Backend Gemini key is not configured.'});
    const imageBase64 = String(req.body?.imageBase64 ?? '');
    const mimeType = String(req.body?.mimeType ?? 'image/jpeg');
    if (!imageBase64 || imageBase64.length > 10_000_000 || !['image/jpeg','image/png','image/webp'].includes(mimeType)) return res.status(400).json({error:'Invalid image or image is too large.'});
    const ai = new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});
    const result = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
      contents: [{role:'user',parts:[{text:String(req.body?.prompt ?? 'Describe this image carefully.').slice(0,2000)},{inlineData:{mimeType,data:imageBase64}}]}]
    });
    res.json({reply:result.text || 'تحلیلی دریافت نشد.'});
  } catch (err) { console.error('image analysis failed',err); res.status(500).json({error:'Image analysis failed. Check backend logs.'}); }
});
app.post('/search', async (req,res) => {
  try {
    const query = String(req.body?.query ?? '').trim().slice(0,300);
    if (!query) return res.status(400).json({error:'query is required'});
    if (!process.env.SERPAPI_KEY) return res.status(503).json({error:'برای جست‌وجوی وب، SERPAPI_KEY را در Backend تنظیم کن.'});
    const url = new URL('https://serpapi.com/search.json'); url.searchParams.set('engine','google'); url.searchParams.set('q',query); url.searchParams.set('api_key',process.env.SERPAPI_KEY);
    const upstream = await fetch(url,{signal:AbortSignal.timeout(20000)});
    if (!upstream.ok) return res.status(502).json({error:'Search provider request failed.'});
    const data = await upstream.json();
    res.json({results:(data.organic_results ?? []).slice(0,6).map(x=>({title:x.title ?? '',link:x.link ?? '',snippet:x.snippet ?? ''}))});
  } catch(err) { console.error('search failed',err); res.status(500).json({error:'Web search failed.'}); }
});

const port = Number(process.env.PORT || 8080);
app.listen(port, () => console.log(`JARVIS backend listening on ${port}`));
